#!/bin/bash
cp * test/breezefield
love test
